"""
AGL Verification Suite
Contains protocols for verifying ASI capabilities independently.
"""
