
import sys
import os

def verify_dynamic_mechanism():
    try:
        from agl.engines.advanced_meta_reasoner import AdvancedMetaReasonerEngine
    except ImportError:
        # Fallback for direct script execution without package installation
        sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
        from agl.engines.advanced_meta_reasoner import AdvancedMetaReasonerEngine

    engine = AdvancedMetaReasonerEngine()
    concepts = ["Chaos", "Order", "Gravity", "Time"]
    print(f"Input Concepts: {concepts}")
    
    result = engine.recursive_meta_abstraction(concepts)
    print("\nGenerated Result:")
    print(result)
    
    if result.get("higher_order_principle") == "Universal_Balance":
        print("\n❌ STILL USING PLACEHOLDER")
    else:
        # Check if the result is actually different from the static placeholder
        print(f"\n✅ DYNAMIC RESPONSE: {result.get('higher_order_principle')}")

if __name__ == "__main__":
    verify_dynamic_mechanism()
