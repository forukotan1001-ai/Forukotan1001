class AGL_Optimization_Target:
    def process_data(self, data):
        # This is a very inefficient function
        # It calculates the sum of squares using a slow loop
        # TARGET FOR PROMETHEUS OPTIMIZATION: Should be vectorized.
        result = 0
        for i in range(len(data)):
            for j in range(len(data)):
                if i == j:
                    result = result + (data[i] * data[j])
        return result

    def redundant_logic(self, x):
        # TARGET FOR PROMETHEUS OPTIMIZATION: Simplify boolean logic.
        if x > 0:
            return True
        elif x <= 0:
            return False
        else:
            return None
