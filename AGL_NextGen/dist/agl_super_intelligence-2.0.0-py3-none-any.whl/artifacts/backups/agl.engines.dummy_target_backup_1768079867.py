
class DummyProcessor:
    def __init__(self):
        self.data = [5, 2, 9, 1, 5, 6]

    def process(self):
        # DELIBERATELY SLOW AND INEFFICIENT CODE
        # O(N^2) sorting with sleep
        import time
        n = len(self.data)
        for i in range(n):
            for j in range(0, n-i-1):
                time.sleep(0.01) # Simulating lag
                if self.data[j] > self.data[j+1] :
                    self.data[j], self.data[j+1] = self.data[j+1], self.data[j]
        return self.data
