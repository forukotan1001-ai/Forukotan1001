import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Button,
  ScrollView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import * as Location from 'expo-location';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const API_URL = 'http://localhost:5000/api';

export default function LocationScreen() {
  const [location, setLocation] = useState(null);
  const [tracking, setTracking] = useState(false);
  const [loading, setLoading] = useState(false);
  const [savedLocations, setSavedLocations] = useState([]);

  useEffect(() => {
    loadSavedLocations();
  }, []);

  const loadSavedLocations = async () => {
    try {
      const locations = await AsyncStorage.getItem('savedLocations');
      if (locations) {
        setSavedLocations(JSON.parse(locations));
      }
    } catch (error) {
      console.log('Error loading locations:', error);
    }
  };

  const getCurrentLocation = async () => {
    try {
      setLoading(true);
      const currentLocation = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });
      setLocation(currentLocation);
    } catch (error) {
      Alert.alert('Error', 'Failed to get location');
    } finally {
      setLoading(false);
    }
  };

  const reportLocation = async () => {
    if (!location) {
      Alert.alert('No Location', 'Please get location first');
      return;
    }

    try {
      setLoading(true);
      const { coords } = location;
      const timestamp = new Date().toISOString();

      const locationData = {
        latitude: coords.latitude,
        longitude: coords.longitude,
        accuracy: coords.accuracy,
        altitude: coords.altitude,
        timestamp,
        userId: 'user_1', // In real app, get from auth context
      };

      // Save to backend
      await axios.post(`${API_URL}/locations`, locationData);

      // Save locally
      const newLocations = [...savedLocations, locationData];
      setSavedLocations(newLocations);
      await AsyncStorage.setItem('savedLocations', JSON.stringify(newLocations));

      Alert.alert('Success', 'Location reported successfully!');
    } catch (error) {
      Alert.alert('Error', 'Failed to report location');
      console.log('Error:', error.message);
    } finally {
      setLoading(false);
    }
  };

  const startTracking = async () => {
    try {
      setTracking(true);
      const subscription = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.High,
          timeInterval: 60000, // Update every 60 seconds
          distanceInterval: 100, // Or when moved 100m
        },
        (newLocation) => {
          setLocation(newLocation);
          // Auto-report location
          reportLocationToBackend(newLocation);
        }
      );

      // Store subscription for cleanup
      await AsyncStorage.setItem('locationSubscription', JSON.stringify(true));
    } catch (error) {
      Alert.alert('Error', 'Failed to start tracking');
    }
  };

  const reportLocationToBackend = async (currentLocation) => {
    try {
      const { coords } = currentLocation;
      await axios.post(`${API_URL}/locations`, {
        latitude: coords.latitude,
        longitude: coords.longitude,
        accuracy: coords.accuracy,
        timestamp: new Date().toISOString(),
        userId: 'user_1',
      });
    } catch (error) {
      console.log('Error reporting location:', error.message);
    }
  };

  const stopTracking = () => {
    setTracking(false);
    AsyncStorage.removeItem('locationSubscription');
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.section}>
        <Text style={styles.title}>Current Location</Text>
        {loading && <ActivityIndicator size="large" color="#007AFF" />}
        {location && (
          <View style={styles.locationInfo}>
            <Text style={styles.text}>
              Latitude: {location.coords.latitude.toFixed(6)}
            </Text>
            <Text style={styles.text}>
              Longitude: {location.coords.longitude.toFixed(6)}
            </Text>
            <Text style={styles.text}>
              Accuracy: {location.coords.accuracy?.toFixed(2)}m
            </Text>
            <Text style={styles.text}>
              Timestamp: {new Date(location.timestamp).toLocaleString()}
            </Text>
          </View>
        )}
      </View>

      <View style={styles.buttonGroup}>
        <Button
          title="Get Current Location"
          onPress={getCurrentLocation}
          color="#007AFF"
        />
      </View>

      <View style={styles.buttonGroup}>
        <Button
          title="Report Location"
          onPress={reportLocation}
          color="#34C759"
          disabled={!location}
        />
      </View>

      <View style={styles.buttonGroup}>
        <Button
          title={tracking ? 'Stop Tracking' : 'Start Tracking'}
          onPress={tracking ? stopTracking : startTracking}
          color={tracking ? '#FF3B30' : '#007AFF'}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.title}>Saved Locations ({savedLocations.length})</Text>
        {savedLocations.slice(-5).reverse().map((loc, idx) => (
          <View key={idx} style={styles.locationItem}>
            <Text style={styles.text}>
              {loc.latitude.toFixed(6)}, {loc.longitude.toFixed(6)}
            </Text>
            <Text style={styles.subtext}>
              {new Date(loc.timestamp).toLocaleString()}
            </Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    padding: 16,
  },
  section: {
    backgroundColor: '#FFF',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 12,
    color: '#000',
  },
  locationInfo: {
    backgroundColor: '#F0F0F0',
    padding: 12,
    borderRadius: 6,
  },
  locationItem: {
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  text: {
    fontSize: 14,
    marginBottom: 4,
    color: '#333',
  },
  subtext: {
    fontSize: 12,
    color: '#999',
  },
  buttonGroup: {
    marginBottom: 12,
    borderRadius: 6,
    overflow: 'hidden',
  },
});
