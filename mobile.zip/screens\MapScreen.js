import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  Button,
  Alert,
} from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function MapScreen() {
  const [locations, setLocations] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [selectedLocation, setSelectedLocation] = React.useState(null);
  const [region, setRegion] = React.useState({
    latitude: 37.78825,
    longitude: -122.4324,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  });

  React.useEffect(() => {
    loadLocations();
  }, []);

  const loadLocations = async () => {
    try {
      setLoading(true);
      const savedLocations = await AsyncStorage.getItem('savedLocations');
      if (savedLocations) {
        const locs = JSON.parse(savedLocations);
        setLocations(locs);

        // Center map on last location
        if (locs.length > 0) {
          const lastLoc = locs[locs.length - 1];
          setRegion({
            latitude: lastLoc.latitude,
            longitude: lastLoc.longitude,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
          });
        }
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to load locations');
    } finally {
      setLoading(false);
    }
  };

  // Generate polyline from locations
  const getPolylineCoordinates = () => {
    return locations.map((loc) => ({
      latitude: loc.latitude,
      longitude: loc.longitude,
    }));
  };

  const clearLocations = () => {
    Alert.alert('Clear All', 'Remove all saved locations?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Clear',
        style: 'destructive',
        onPress: async () => {
          await AsyncStorage.removeItem('savedLocations');
          setLocations([]);
        },
      },
    ]);
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>Loading map...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {locations.length > 0 ? (
        <>
          <MapView style={styles.map} region={region} onRegionChange={setRegion}>
            {/* Draw path between locations */}
            {locations.length > 1 && (
              <Polyline
                coordinates={getPolylineCoordinates()}
                strokeColor="#007AFF"
                strokeWidth={2}
                geodesic
              />
            )}

            {/* Mark start location */}
            {locations.length > 0 && (
              <Marker
                coordinate={{
                  latitude: locations[0].latitude,
                  longitude: locations[0].longitude,
                }}
                title="Start"
                description={new Date(locations[0].timestamp).toLocaleString()}
                pinColor="green"
              />
            )}

            {/* Mark all locations */}
            {locations.map((location, idx) => (
              <Marker
                key={idx}
                coordinate={{
                  latitude: location.latitude,
                  longitude: location.longitude,
                }}
                title={`Location ${idx + 1}`}
                description={new Date(location.timestamp).toLocaleString()}
                onPress={() => setSelectedLocation(location)}
                pinColor={idx === locations.length - 1 ? 'red' : '#007AFF'}
              />
            ))}
          </MapView>

          {selectedLocation && (
            <View style={styles.infoPanel}>
              <Text style={styles.infoTitle}>Location Details</Text>
              <Text style={styles.infoText}>
                Latitude: {selectedLocation.latitude.toFixed(6)}
              </Text>
              <Text style={styles.infoText}>
                Longitude: {selectedLocation.longitude.toFixed(6)}
              </Text>
              <Text style={styles.infoText}>
                Accuracy: {selectedLocation.accuracy?.toFixed(2)}m
              </Text>
              <Text style={styles.infoText}>
                {new Date(selectedLocation.timestamp).toLocaleString()}
              </Text>
            </View>
          )}

          <View style={styles.statsBox}>
            <Text style={styles.statsText}>Locations: {locations.length}</Text>
            {locations.length > 1 && (
              <Text style={styles.statsText}>
                Distance: {calculateDistance(locations).toFixed(2)}km
              </Text>
            )}
          </View>

          <View style={styles.buttonGroup}>
            <Button title="Refresh" onPress={loadLocations} color="#007AFF" />
          </View>

          <View style={styles.buttonGroup}>
            <Button title="Clear All" onPress={clearLocations} color="#FF3B30" />
          </View>
        </>
      ) : (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No locations tracked yet</Text>
          <Text style={styles.emptySubtext}>
            Start tracking to see your journey on the map
          </Text>
        </View>
      )}
    </View>
  );
}

// Calculate total distance traveled
function calculateDistance(locations) {
  if (locations.length < 2) return 0;

  let totalDistance = 0;
  for (let i = 0; i < locations.length - 1; i++) {
    const R = 6371; // Earth radius in km
    const dLat = (toRad(locations[i + 1].latitude) - toRad(locations[i].latitude));
    const dLon = (toRad(locations[i + 1].longitude) - toRad(locations[i].longitude));
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(toRad(locations[i].latitude)) * Math.cos(toRad(locations[i + 1].latitude)) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    totalDistance += R * c;
  }
  return totalDistance;
}

function toRad(degrees) {
  return degrees * (Math.PI / 180);
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  map: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 14,
    color: '#666',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
  },
  infoPanel: {
    backgroundColor: '#FFF',
    padding: 12,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
    color: '#000',
  },
  infoText: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  statsBox: {
    backgroundColor: '#FFF',
    padding: 12,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statsText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
  },
  buttonGroup: {
    padding: 12,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
  },
});
