import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Button,
  ScrollView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const API_URL = 'http://localhost:5000/api';

export default function WorkScreen() {
  const [loading, setLoading] = useState(false);
  const [importedWork, setImportedWork] = useState([]);

  useEffect(() => {
    loadImportedWork();
  }, []);

  const loadImportedWork = async () => {
    try {
      const work = await AsyncStorage.getItem('importedWork');
      if (work) {
        setImportedWork(JSON.parse(work));
      }
    } catch (error) {
      console.log('Error loading work:', error);
    }
  };

  const pickAndImportFile = async () => {
    try {
      setLoading(true);
      const result = await DocumentPicker.getDocumentAsync({
        type: ['text/csv', 'application/json', 'application/vnd.ms-excel'],
      });

      if (!result.canceled && result.assets[0]) {
        const file = result.assets[0];
        await processWorkFile(file);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to pick file');
    } finally {
      setLoading(false);
    }
  };

  const processWorkFile = async (file) => {
    try {
      setLoading(true);
      const fileContent = await FileSystem.readAsStringAsync(file.uri);

      // Parse CSV or JSON
      let workData = [];
      if (file.name.endsWith('.csv')) {
        workData = parseCSV(fileContent);
      } else if (file.name.endsWith('.json')) {
        workData = JSON.parse(fileContent);
      } else {
        throw new Error('Unsupported file format');
      }

      // Send to backend
      await axios.post(`${API_URL}/work/import`, {
        data: workData,
        fileName: file.name,
        importedAt: new Date().toISOString(),
        userId: 'user_1',
      });

      // Save locally
      const allWork = [...importedWork, ...workData];
      setImportedWork(allWork);
      await AsyncStorage.setItem('importedWork', JSON.stringify(allWork));

      Alert.alert('Success', `Imported ${workData.length} work items!`);
    } catch (error) {
      Alert.alert('Error', error.message);
      console.log('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const parseCSV = (content) => {
    const lines = content.split('\n');
    const headers = lines[0].split(',');
    const data = [];

    for (let i = 1; i < lines.length; i++) {
      if (lines[i].trim()) {
        const values = lines[i].split(',');
        const obj = {};
        headers.forEach((header, idx) => {
          obj[header.trim()] = values[idx]?.trim();
        });
        data.push(obj);
      }
    }
    return data;
  };

  const createSampleWork = async () => {
    try {
      setLoading(true);
      const sampleWork = [
        {
          id: 'work_1',
          title: 'Field Survey A',
          description: 'Survey work completed',
          hours: 4.5,
          date: new Date().toISOString().split('T')[0],
          status: 'completed',
        },
        {
          id: 'work_2',
          title: 'Field Survey B',
          description: 'Ongoing survey work',
          hours: 3.0,
          date: new Date().toISOString().split('T')[0],
          status: 'in-progress',
        },
      ];

      await axios.post(`${API_URL}/work/import`, {
        data: sampleWork,
        fileName: 'sample_work.json',
        importedAt: new Date().toISOString(),
        userId: 'user_1',
      });

      const allWork = [...importedWork, ...sampleWork];
      setImportedWork(allWork);
      await AsyncStorage.setItem('importedWork', JSON.stringify(allWork));

      Alert.alert('Success', 'Sample work created!');
    } catch (error) {
      Alert.alert('Error', 'Failed to create sample work');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      {loading && (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#007AFF" />
          <Text style={styles.loadingText}>Processing...</Text>
        </View>
      )}

      <View style={styles.section}>
        <Text style={styles.title}>Import Work</Text>
        <Text style={styles.description}>
          Upload a CSV or JSON file with your work data
        </Text>
      </View>

      <View style={styles.buttonGroup}>
        <Button
          title="Pick & Import Work File"
          onPress={pickAndImportFile}
          color="#007AFF"
          disabled={loading}
        />
      </View>

      <View style={styles.buttonGroup}>
        <Button
          title="Create Sample Work"
          onPress={createSampleWork}
          color="#34C759"
          disabled={loading}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.title}>Imported Work ({importedWork.length})</Text>
        {importedWork.length === 0 ? (
          <Text style={styles.emptyText}>No work items imported yet</Text>
        ) : (
          importedWork.slice(-5).reverse().map((work, idx) => (
            <View key={idx} style={styles.workItem}>
              <Text style={styles.workTitle}>{work.title || work.name}</Text>
              <Text style={styles.text}>
                {work.description || work.status || 'No description'}
              </Text>
              {work.hours && (
                <Text style={styles.subtext}>Hours: {work.hours}</Text>
              )}
              {work.date && (
                <Text style={styles.subtext}>Date: {work.date}</Text>
              )}
            </View>
          ))
        )}
      </View>

      <View style={styles.section}>
        <Text style={styles.title}>File Format Examples</Text>
        <Text style={styles.codeBlock}>
{`CSV Format:
title,description,hours,date,status
Field Survey,Survey work,4.5,2024-02-10,completed

JSON Format:
[{
  "title": "Field Survey",
  "description": "Survey work",
  "hours": 4.5,
  "date": "2024-02-10",
  "status": "completed"
}]`}
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    padding: 16,
  },
  loadingContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 20,
  },
  loadingText: {
    marginTop: 8,
    fontSize: 14,
    color: '#007AFF',
  },
  section: {
    backgroundColor: '#FFF',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 8,
    color: '#000',
  },
  description: {
    fontSize: 14,
    color: '#666',
  },
  workItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  workTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    marginBottom: 4,
  },
  text: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  subtext: {
    fontSize: 12,
    color: '#999',
  },
  emptyText: {
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
    paddingVertical: 20,
  },
  buttonGroup: {
    marginBottom: 12,
    borderRadius: 6,
    overflow: 'hidden',
  },
  codeBlock: {
    fontFamily: 'monospace',
    backgroundColor: '#F0F0F0',
    padding: 10,
    borderRadius: 4,
    fontSize: 11,
    color: '#333',
    lineHeight: 16,
  },
});
