import os
import pathlib
import pytest

# Ensure matplotlib runs headless during tests to avoid GUI requirements
os.environ.setdefault("MPLBACKEND", "Agg")


@pytest.fixture(scope="session", autouse=True)
def _bootstrap_test_inputs(tmp_path_factory):
    """Create small stub files and folders that tests expect.

    This prevents pytest collection errors when tests reference reports/ or artifacts/
    and provides small, deterministic inputs for CI/local runs.
    """
    root = pathlib.Path.cwd()

    # Create reports/ and a simple test input file
    rpt = root / "reports"
    rpt.mkdir(parents=True, exist_ok=True)
    (rpt / "agl_test_input.txt").write_text("OK: test seed\n", encoding="utf-8")

    # Create artifacts/ (some tests expect it)
    (root / "artifacts").mkdir(parents=True, exist_ok=True)

    # Create small HTML stubs for reports some tests open
    for p in ["reports/models_report.html", "reports/full_system_report.html"]:
        f = root / p
        if not f.exists():
            f.write_text("<html><body>stub</body></html>", encoding="utf-8")

    return True
