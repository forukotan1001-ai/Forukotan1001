## [0.1.0] - Initial Private Beta

- Cohesion: 100/100
- DKN ready
- Quantum Simulator Wrapper stable
- Registry core services present
- Callable MetaOrchestrator
